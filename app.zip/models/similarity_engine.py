
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import LabelEncoder, StandardScaler

class SimilarityEngine:
    def __init__(self, path):
        self.df = pd.read_csv(path)
        self.features = ["Age","BMI","AMH","FSH","LH","Diagnosis","PreviousFailures"]

        self.le = LabelEncoder()
        self.df["Diagnosis"] = self.le.fit_transform(self.df["Diagnosis"])

        self.scaler = StandardScaler()
        X = self.scaler.fit_transform(self.df[self.features])

        self.knn = NearestNeighbors(n_neighbors=5)
        self.knn.fit(X)

    def find(self, patient):
        import pandas as pd
        p = pd.DataFrame([patient])
        p["Diagnosis"] = self.le.transform([patient["Diagnosis"]])
        p_scaled = self.scaler.transform(p[self.features])
        _, idx = self.knn.kneighbors(p_scaled)
        return self.df.iloc[idx[0]]
