import joblib
import pandas as pd

model = joblib.load("models/saved_model.pkl")
encoder = joblib.load("models/label_encoder.pkl")   


def predict_success(patient):

    df = pd.DataFrame([patient])

  
    df["Diagnosis"] = encoder.transform(df["Diagnosis"])

    prob = model.predict_proba(df)[0][1]

    return round(prob * 100, 2)