import sys, os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

import streamlit as st
import pandas as pd

from rules.clinical_rules import rule_recommendation
from models.similarity_engine import SimilarityEngine
from models.predictor import predict_success   

DATA = "data/fertility_clinical_dataset_1200.csv"
sim_engine = SimilarityEngine(DATA)

st.title("Fertility Clinical Decision Support System")

# -------- FORM --------
with st.form("patient_form"):

    col1, col2 = st.columns(2)

    with col1:
        age = st.number_input("Age", 18, 50, 30)
        bmi = st.number_input("BMI", 10.0, 50.0, 24.0)
        amh = st.number_input("AMH", 0.0, 10.0, 2.5)

    with col2:
        fsh = st.number_input("FSH", 0.0, 30.0, 7.0)
        lh = st.number_input("LH", 0.0, 30.0, 6.0)
        fails = st.number_input("Previous Failures", 0, 10, 0)

    diag = st.selectbox(
        "Diagnosis",
        ["Normal", "PCOS", "Endometriosis", "MaleFactor", "Tubal"]
    )

    submit = st.form_submit_button("Analyze")


# -------- PREDICTION --------
if submit:

    patient = {
        "Age": age,
        "BMI": bmi,
        "AMH": amh,
        "FSH": fsh,
        "LH": lh,
        "Diagnosis": diag,
        "PreviousFailures": fails
    }

    # 1️⃣ Rule Engine
    rule = rule_recommendation(patient)

    st.subheader("Rule-based Recommendation")
    st.success(rule)


    # 2️⃣ ML Prediction  ✅ NEW
    prob = predict_success(patient)

    st.subheader("ML Success Prediction")
    st.info(f"Predicted Success Probability: {prob}%")


    # 3️⃣ Similarity Search
    st.subheader("Similar Patients")
    st.dataframe(sim_engine.find(patient))